#include<iostream>	//access input output related code
using namespace std;	//use the C++ standard namespace which includes cin and cout

int main() {	//declare the main function
	cout << "Hello world!";	//display message on the screen
	return 0;	//terminate main thereby the program
}